# ml_algo_tut
Sonar data classfication using Decision Tree , Random Forest, Support Vector Machine &amp; Mulit Layer Perceptron
