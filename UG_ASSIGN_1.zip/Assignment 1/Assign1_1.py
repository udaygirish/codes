list_tuples = [(1,2),(2,3),(2,3),(2,3),(3,4),(1,2,3),(2,4,5),(1,2,3),(3,4,5)]
li=[]
for i in list_tuples:
    if i not in li:
        li.append(i)
        print("The number of times of occurence of",i,":",list_tuples.count(i))


