# coding: utf-8
diction = { "black" :  "r", 
  "hero": "e", 
  "go" : "g", 
  "clue":"i",
  "mean":"q",
  "groan":"o",
  "sin":"p",
  "pint":"u",
  "tone":"n",
  "graze":"s",
  "sea":"t",
  "plant":"a"}

def compare(string):
    count = 0
    for i in range(len(string)):
        if string[i] in value:
            count+=1
    if (count == len(string)):
        return string

pres_key=[]
key=[]
value=[]

list(diction.keys())
for i in diction.keys():
    key.append(i)

for i in diction:
    value.append(diction[i])
for i in key:
    pres_key.append(compare(i))

count = 0
for i in range(len(pres_key)):
    if(pres_key[i] != None):
        count+=1
for i in range(count):
    pres_key.remove(None)

print(pres_key)



