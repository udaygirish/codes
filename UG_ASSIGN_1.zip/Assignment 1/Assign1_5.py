'''
# Meant for python mostly.
A mutable object can be changed after it's created, and an immutable object can't be changed.

String and Tuple are immutable objects
List and Dictionary are mutable objects.

Immutable objects were handled differently in python and their copies can be changed or modified.


'''









