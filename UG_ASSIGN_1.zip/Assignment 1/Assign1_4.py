listA = [(1,2), (4,3), (2,10), (12, 5), (6, 7), (9,11), (15, 4)]
listA.sort(key=lambda elem: elem[0])
print("Increasing Order with first element of Tuple:",listA)
listA.sort(key=lambda elem: elem[1])
print("Increasing Order with second element of Tuple:",listA)
listA.sort(key=lambda elem: elem[0],reverse=True)
print("Decreasing Order with first element of Tuple:",listA)
listA.sort(key=lambda elem: elem[1],reverse=True)
print("Decreasing Order with first element of Tuple:",listA)